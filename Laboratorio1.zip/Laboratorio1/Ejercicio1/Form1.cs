﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Ejercicio1
{
    public partial class Ejemplo1 : Form
    {

        public double num1, num2, resultado;
        public bool Is1, Is2, Es_op;
        int operacion;

        private void button1_Click(object sender, EventArgs e)
        {
            actualizarPantalla("0");
        }

        private void button2_Click(object sender, EventArgs e)
        {
            actualizarPantalla("1");
        }

        private void button3_Click(object sender, EventArgs e)
        {
            actualizarPantalla("2");
        }

        private void button4_Click(object sender, EventArgs e)
        {
            actualizarPantalla("3");
        }

        private void button5_Click(object sender, EventArgs e)
        {
            actualizarPantalla("4");
        }

        private void button6_Click(object sender, EventArgs e)
        {
            actualizarPantalla("5");
        }

        private void button7_Click(object sender, EventArgs e)
        {
            actualizarPantalla("6");
        }

        private void button8_Click(object sender, EventArgs e)
        {
            actualizarPantalla("7");
        }

        private void button9_Click(object sender, EventArgs e)
        {
            actualizarPantalla("8");
        }

        private void button10_Click(object sender, EventArgs e)
        {
            actualizarPantalla("9");
        }

        private void button12_Click(object sender, EventArgs e)
        {
            limpiarPantalla();
        }

        private void button13_Click(object sender, EventArgs e)
        {
            if (!Is1)
            {
                num1 = obtenerValor();
                Is1 = true;
                operacion = 0;
            }
        }

        private void button17_Click(object sender, EventArgs e)
        {
            try
            {
                if (Is1)
                {
                    num2 = obtenerValor();
                    actualizarPantalla(operar(num1,num2,"+").ToString());
                    Is1 = false;
                }
                else
                {
                    MessageBox.Show("Seleccione una operacion a realizar");
                }
            }
            catch
            {
                MessageBox.Show("Esta operacion requiere dos operandos");
            }
        }

        public Ejemplo1()
        {
            InitializeComponent();
            Is1 = Is2 = false;
        }

        public void limpiarPantalla()
        {
            Pantalla.Clear();
        }

        public double obtenerValor()
        {
            double valor = Convert.ToDouble(Pantalla.Text);
            limpiarPantalla();
            return valor;
        }

        public void actualizarPantalla(String texto)
        {
            Pantalla.Text = Pantalla.Text + texto;
        }

        public double operar(double operador1, double operador2, string signo)
        {
            double Resultado = 0.0;
            switch (signo)
            {
                case "+":
                    Resultado = operador1 + operador2;
                    break;
                case "-":
                    Resultado = operador1 - operador2;
                    break;
                case "*":
                    Resultado = operador1 * operador2;
                    break;
                case "/":
                    Resultado = operador1 / operador2;
                    break;
                default:
                    break;
            }
            return Resultado;
        }

    }
}
