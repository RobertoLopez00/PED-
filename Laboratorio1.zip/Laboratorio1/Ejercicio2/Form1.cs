﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Ejercicio2
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            boton1 = new Button();
            boton1.Size = new Size(80,40);
            boton1.Location = new Point(30,30);
            boton1.Text = "Presione aquí";
            this.Controls.Add(boton1);
            boton1.Click += new EventHandler(boton1_Click_1);
        }

        private void boton1_Click_1(object sender, EventArgs e)
        {
            MessageBox.Show("Se ha creado un boton por codigo");
        }
    }
}
